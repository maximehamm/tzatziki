var {Then} = require('cucumber');
var {When} = require('cucumber');
var {Given} = require('cucumber');

Given(/^Romeo who wants to buy a drink$/, function () {

});
When(/^an order is declared for Juliette$/, function () {
    return true;
});
Then(/^there is (\d+) cocktails in the order$/, function () {

});
Then(/^Romeo pays his order$/, function () {

});
Given(/^I have the following books in the store$/, function () {

});
Then(/^the ticket must say "([^"]*)"$/, function () {
    return "From Romeo to Juliette: Wanna chat?";
});